import unittest
from deal_analyzer import DealInputs, analyze_deal, qualify_lead

class DealAnalyzerTests(unittest.TestCase):
    def test_mao(self):
        result = analyze_deal(DealInputs(200000, 20000, 100000, 10000, 5000))
        self.assertEqual(result["maximum_allowable_offer_estimate"], 105000)
        self.assertEqual(result["status"], "WITHIN_SCREENING_RANGE")
    def test_negative_mao_is_zero_and_flagged(self):
        result = analyze_deal(DealInputs(100000, 50000, 10000, 20000))
        self.assertEqual(result["maximum_allowable_offer_estimate"], 0)
        self.assertEqual(result["status"], "REVIEW_REQUIRED")
    def test_negative_input_rejected(self):
        with self.assertRaises(ValueError):
            analyze_deal(DealInputs(100000, -1, 50000))
    def test_bad_factor_rejected(self):
        with self.assertRaises(ValueError):
            analyze_deal(DealInputs(100000, 10000, 50000, investor_margin_factor=1.2))
    def test_lead_stays_human_review(self):
        lead = qualify_lead(property_address="123 Example St",
            owner_authority_confirmed=True, seller_timeline="3 months",
            property_condition="Needs roof", human_follow_up_requested=True)
        self.assertEqual(lead["stage"], "HUMAN_REVIEW_REQUIRED")
        self.assertFalse(lead["contact_authorized"])
        self.assertFalse(lead["offer_authorized"])

if __name__ == "__main__":
    unittest.main()
