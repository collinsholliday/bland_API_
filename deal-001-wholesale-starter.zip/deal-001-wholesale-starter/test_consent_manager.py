import unittest
from consent_manager import ConsentRecord, consent_is_valid

class ConsentManagerTests(unittest.TestCase):
    def test_missing(self):
        self.assertFalse(consent_is_valid(None))
    def test_valid(self):
        self.assertTrue(consent_is_valid(ConsentRecord("seller-1", "AI voice call", "Recorded permission", True)))
    def test_wrong_scope(self):
        self.assertFalse(consent_is_valid(ConsentRecord("seller-1", "text", "Recorded permission", True)))
    def test_unverified(self):
        self.assertFalse(consent_is_valid(ConsentRecord("seller-1", "AI voice call", "Recorded permission", False)))

if __name__ == "__main__":
    unittest.main()
