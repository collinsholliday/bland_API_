"""Bland AI dry-run client; never places a call."""
def prepare_call(phone_number: str, task: str) -> dict:
    if not phone_number or not task:
        raise ValueError("Phone number and task are required.")
    return {"phone_number": phone_number, "task": task, "dry_run": True, "live_call_sent": False}

def send_call(*args, **kwargs):
    raise PermissionError("Live calling is disabled; use human review and verified consent.")
