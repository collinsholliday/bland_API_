# Deal 001 — Wholesale Real Estate Starter

Zero-cost, human-reviewed seller qualification and deal-screening starter.

## Safeguards
- No live calls, texts, emails, seller contact, offers, contracts, purchases, or paid services are enabled.
- Bland requests are dry-run only. Missing consent means no contact.
- Norma must identify herself as AI, ask permission, respect opt-outs, and hand off legal/title/probate/foreclosure questions.
- A GitHub secret does not itself connect an API or authorize usage.

## Deal screening
MAO estimate = ARV × investor margin factor − repairs − assignment fee target − closing/holding costs.

Defaults are a 70% factor and $10,000 assignment-fee target. These are assumptions, not universal rules, appraisals, offers, or guarantees. Verify sold comparables, repair estimates, costs, title, buyer demand, and local law.

## Run tests
Requires Python 3.10+; no third-party packages:
`python -m unittest -v`

This is not brokerage, legal, tax, lending, or investment advice. Get local legal guidance before marketing equitable interests, signing, or assigning contracts.
