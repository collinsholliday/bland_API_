"""Transparent, assumption-based wholesale deal screening; not an appraisal or offer."""
from dataclasses import dataclass, asdict

@dataclass(frozen=True)
class DealInputs:
    arv: float
    repairs: float
    asking_price: float
    assignment_fee_target: float = 10000.0
    closing_and_holding_costs: float = 0.0
    investor_margin_factor: float = 0.70

def analyze_deal(inputs: DealInputs) -> dict:
    for name, value in asdict(inputs).items():
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(f"{name} must be numeric")
        if value < 0:
            raise ValueError(f"{name} cannot be negative")
    if inputs.arv <= 0:
        raise ValueError("ARV must be greater than zero")
    if not 0 < inputs.investor_margin_factor <= 1:
        raise ValueError("Margin factor must be greater than 0 and at most 1")
    mao = (inputs.arv * inputs.investor_margin_factor - inputs.repairs
           - inputs.assignment_fee_target - inputs.closing_and_holding_costs)
    spread = mao - inputs.asking_price
    status = ("REVIEW_REQUIRED" if mao <= 0 else
              "WITHIN_SCREENING_RANGE" if spread >= 0 else
              "ABOVE_SCREENING_RANGE")
    return {
        "status": status,
        "maximum_allowable_offer_estimate": round(max(0.0, mao), 2),
        "estimated_spread_at_asking_price": round(spread, 2),
        "inputs": asdict(inputs),
        "formula": "ARV × factor − repairs − assignment fee target − closing/holding costs",
        "disclaimer": "Preliminary estimate only; verify comps, condition, title, liens, costs, buyer demand, contract assignability, and local law. Not an offer or valuation."
    }

def qualify_lead(*, property_address: str, owner_authority_confirmed: bool,
                 seller_timeline: str, property_condition: str,
                 human_follow_up_requested: bool) -> dict:
    if not property_address.strip():
        raise ValueError("Property address is required")
    return {
        "property_address": property_address.strip(),
        "owner_authority_confirmed": bool(owner_authority_confirmed),
        "seller_timeline": seller_timeline.strip(),
        "property_condition": property_condition.strip(),
        "human_follow_up_requested": bool(human_follow_up_requested),
        "stage": "HUMAN_REVIEW_REQUIRED",
        "contact_authorized": False,
        "offer_authorized": False,
    }
